console.log("ajiaskioskoasksoksoksoskosksok")



$(document).ready(function() {
  // Function to display "Hello, World!"
  function sayHello() {
    console.log("Hello, sssssWorld!");
  }

  // Call the function when the page is ready
  sayHello();
});
